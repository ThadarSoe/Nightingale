CREATE DATABASE Nightingale 

CREATE TABLE Favourites(
	SessionID int NOT NULL PRIMARY KEY,
	Title nvarchar(100) NOT NULL,
	Category nvarchar(100) NOT NULL
);




